# Redis → WebSocket 브로드캐스트
import asyncio
import json
from _shared.redis_client import redis_conn
from fastapi import WebSocket
from web_app.api.websocket import active_connections

async def broadcast_from_redis():
    pubsub = redis_conn.pubsub()
    await pubsub.subscribe("orders", "trades", "accounts")
    while True:
        message = await pubsub.get_message(ignore_subscribe_messages=True, timeout=1.0)
        if message:
            data = json.loads(message["data"])
            for ws in active_connections:
                await ws.send_json(data)
        await asyncio.sleep(0.1)
