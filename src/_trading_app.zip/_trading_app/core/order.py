from typing import Optional, Dict, List
from ib_insync import IB, Stock, Future, Order, AccountValue
from src.shared.exceptions import OrderException
from src.shared.logger import setup_logger
import logging

logger = logging.getLogger(__name__)


class Order:
    def __init__(self, ib:IB):
        self.ib = ib
        self.positions: Dict[str, str] = {}  # 예: {"MNQ": "LONG"}
        self.logger = setup_logger("order_manager")


    def handle_signal(
            self,
            symbol: str,
            action: str,
            quantity: int,
            order_id: str,
            order_type: str = "MKT",
            limit_price: float = 0.0,
            stop_price: float = 0.0,
            slippage: float = 0.0,
            tif: str = "DAY",
            asset_type: str = "STK",
            exchange: str = "SMART",
            session: str = "normal",
            position_size: float = 0.0,
            strategy: str = "",
            entry_condition: str = "",
            timestamp: str = ""
    ) -> bool:
        """
        action: BUY / SELL / CLOSE
        order_type: MKT / LMT / STP / STP LMT
        tif: Time-in-Force: GTC, DAY, etc.
        """
        action = action.upper()
        order_type = order_type.upper()
        asset_type = asset_type.upper()

        # 자동으로 현재 가격을 가져옴 (지정가 or 조건부 주문인 경우)
        # if order_type in ("LMT", "STP LMT") and limit_price is None:
        #     limit_price = self.market.get_market_price(symbol)
        #     self.logger.info(f"Limit price not specified, using market price: {limit_price}")

        self.logger.info(
            f"Signal: {action} {quantity}×{symbol} | Type: {order_type}, Limit: {limit_price}, Stop: {stop_price}")

        return self.execute_position(
            symbol=symbol,
            action=action,
            quantity=quantity,
            order_type=order_type,
            limit_price=limit_price,
            stop_price=stop_price,
            tif=tif,
            asset_type=asset_type,
            exchange=exchange
        )

    def execute_position(
            self,
            symbol: str,
            action: str,
            quantity: int,
            order_type: str = "MKT",
            limit_price: Optional[float] = None,
            stop_price: Optional[float] = None,
            tif: str = "GTC",
            asset_type: str = "STK",
            exchange: Optional[str] = None
    ) -> bool:
        """
        주문 실행 로직 (롱/숏/청산) 통합 처리
        """
        try:
            # if not self.trading_hours.is_market_open():
            #     self.logger.warning("Market is closed")
            #     return False

            # if not self.order.check_sufficient_funds():
            #     self.logger.warning("Insufficient funds")
            #     return False

            # 지정가나 스탑 주문인데 가격이 없으면 시장가로 대체
            # if order_type in ("LMT", "STP LMT") and limit_price is None:
            #     limit_price = self.market.get_market_price(symbol)
            #     self.logger.info(f"Defaulted limit price to market price: {limit_price}")

            # 포지션 청산은 매수/매도 방향 반대로
            if action == "CLOSE":
                # 포지션 방향을 판단하고 반대 주문 실행 (예: 현재 LONG → SHORT)
                action = self.get_opposite_position(symbol)
                self.logger.info(f"CLOSE requested, reversing to action: {action}")

            # 주문 실행
            success = self.place_order(
                symbol=symbol,
                quantity=quantity,
                action=action,
                order_type=order_type,
                limit_price=limit_price,
                stop_price=stop_price,
                tif=tif,
                asset_type=asset_type,
                exchange=exchange
            )

            # 예시로 거래 기록 저장, 이메일 전송 등 추가 가능
            if success:
                self.logger.info(f"Order executed: {action} {quantity}×{symbol}")
            else:
                self.logger.warning(f"Order failed: {action} {quantity}×{symbol}")

            return success

        except Exception as e:
            self.logger.error(f"Execution failed: {str(e)}")
            return False

    def place_order(
            self,
            symbol: str,
            quantity: int,
            action: str,
            order_type: str,
            limit_price: Optional[float],
            stop_price: Optional[float],
            tif: str,
            asset_type: str,
            exchange: Optional[str]
    ) -> bool:
        """
        IBKR 주문 실행 함수 (롱/숏 포함)
        action: LONG / SHORT
        order_type: MKT / LMT / STP / STP LMT
        """
        try:
            # 계약 생성 (주식, 선물 등 유형별로 구분 가능)
            contract = self.create_contract(symbol, asset_type, exchange)

            # 주문 객체 생성
            order = self.build_order(
                action=action,
                quantity=quantity,
                order_type=order_type,
                limit_price=limit_price,
                stop_price=stop_price,
                tif=tif
            )

            # 주문 전송
            self.ib.placeOrder(contract, order)
            self.logger.info(f"Placed {action} order for {quantity}×{symbol}")
            self.logger.info(contract)
            self.logger.info(order)
            return True

        except Exception as e:
            self.logger.error(f"Failed to place order: {str(e)}")
            return False


    def create_contract(self, symbol: str, asset_type: str, exchange: Optional[str]):
        if asset_type == "STK":
            return Stock(symbol, exchange or "SMART", "USD")
        elif asset_type == "FUT":
            return Future(symbol, exchange or "GLOBEX", "USD")
        else:
            raise ValueError(f"Unsupported asset type: {asset_type}")


    def build_order(self, action: str, quantity: int, order_type: str,
                     limit_price: Optional[float], stop_price: Optional[float], tif: str):

        # action = "BUY" if action == "LONG" else "SELL"
        if action in ("LONG", "BUY"):
            action = "BUY"
        elif action in ("SHORT", "SELL"):
            action = "SELL"

        order = Order()
        order.action = action
        order.totalQuantity = quantity
        order.tif = tif

        if order_type == "MKT":
            order.orderType = "MKT"
        elif order_type == "LMT":
            order.orderType = "LMT"
            order.lmtPrice = limit_price
        elif order_type == "STP":
            order.orderType = "STP"
            order.auxPrice = stop_price
        elif order_type == "STP LMT":
            order.orderType = "STP LMT"
            order.lmtPrice = limit_price
            order.auxPrice = stop_price
        else:
            raise ValueError(f"Unsupported order type: {order_type}")

        return order


    def get_opposite_position(self, symbol: str) -> str:
        """현재 포지션과 반대 방향을 반환"""
        current = self.positions.get(symbol)
        if current == "LONG":
            return "SHORT"
        elif current == "SHORT":
            return "LONG"
        else:
            return "LONG"  # 포지션 없는 경우 기본값

