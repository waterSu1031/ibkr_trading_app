from typing import Optional, Dict
import os
import time
import logging
from ib_insync import IB

from src._trading_app.core.market import Market
from src._trading_app.core.order import Order
from src.shared.logger import setup_logger
from src.utils.reporter import Reporter
from src.utils.screenshotter import Screenshotter
from src.utils.email_sender import EmailSender
from src.shared.exceptions import MarketDataException

logger = logging.getLogger(__name__)


class TradingApp:
    def __init__(self):
        self.ib = IB()
        self.connection_timeout = 30  # 30 seconds timeout
        self.retry_interval = 5  # 5 seconds between retries
        self.max_retries = 3  # Maximum number of connection attempts

        # self.logger      = setup_logger("_web_app")
        self.logger         = logger
        self.market         = Market(self.ib)
        self.order          = Order(self.ib)
        self.reporter       = Reporter()
        self.screenshot     = Screenshotter()
        self.emailer        = EmailSender(raise_on_missing_credentials=False)
        # positions: symbol → {'side':'LONG'|'SHORT', 'quantity':int, 'entry_price':float}
        self.positions: Dict[str, Dict] = {}

    def connect(self, port: int, host: str = "127.0.0.1", client_id: int = 0) -> bool:
        """Connect to IBKR with retries"""
        for attempt in range(self.max_retries):
            try:
                if self.ib.isConnected():
                    self.ib.disconnect()
                    time.sleep(1)

                self.ib.connect(
                    host=host,
                    port=port,
                    clientId=client_id,
                    timeout=self.connection_timeout
                )
                time.sleep(1)
                # self.ib.reqMarketDataType(3)  # 3 = Delayed data
                # logger.info("Enabled delayed market data")

                if self.ib.isConnected():
                    print(f"Successfully connected to IBKR on port {port}")
                    return True

            except Exception as e:
                print(f"Connection attempt {attempt + 1} failed: {str(e)}")
                if attempt < self.max_retries - 1:
                    print(f"Retrying in {self.retry_interval} seconds...")
                    time.sleep(self.retry_interval)

        raise MarketDataException("Failed to connect after all retry attempts")

    def disconnect(self):
        """Disconnect from IBKR"""
        if self.ib.isConnected():
            self.ib.disconnect()

    def is_connected(self) -> bool:
        """Check if connected to IBKR"""
        return self.ib.isConnected()



    def send_report(self) -> None:
        try:
            paths = self.reporter.generate_report()
            recv = os.getenv("TRADING_REPORT_EMAIL")
            if recv:
                summary = {
                    "open_positions": self.positions,
                    "timestamp": self.trading_hours.current_timestamp()
                }
                self.emailer.send_report(recv, paths, summary)
            else:
                self.logger.info("No report email configured - skipping.")
        except Exception as e:
            self.logger.error(f"Report error: {e}")


# 모듈 레벨로 핸들러만 노출
trading_app = TradingApp()


if __name__ == "__main__":
    trading_app.connect(port=4002)

    #
    # @asynccontextmanager
    # async def dashboard_life(app: FastAPI):
    #     # FastAPI 상태에 IB 연결 저장
    #     ib = IB()
    #     await ib.connectAsync(
    #         host="127.0.0.1",
    #         port=4002,
    #         clientId=1
    #     )
    #     app.state.ib = ib
    #
    #     register_event_handlers(ib)
    #     # asyncio.create_task(ib.runAsync())
    #     # asyncio.create_task(start_sync_loop(ib))
    #     threading.Thread(target=ib.run, daemon=True).start()
    #     # threading.Thread(target=start_sync_loop, args=(ib,), daemon=True).start()
    #     print("🔌 IB 연결됨")
    #
    #     yield
    #
    #     if ib.isConnected():
    #         ib.disconnect()
    #         print("❎ IB Gateway 연결 해제 완료")