#!/bin/bash
echo "🚀 Starting Trading Logic..."
exec python main.py
